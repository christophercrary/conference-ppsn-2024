// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: Copyright 2019-2024 Heal Research

#ifndef OPERON_BACKEND_FASTOR_HPP
#define OPERON_BACKEND_FASTOR_HPP

#include "fastor/derivatives.hpp"

#endif