// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: Copyright 2019-2024 Heal Research

#ifndef OPERON_BACKEND_PLAIN_HPP
#define OPERON_BACKEND_PLAIN_HPP

#include "plain/derivatives.hpp"

#endif