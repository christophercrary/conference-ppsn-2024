// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: Copyright 2019-2024 Heal Research

#ifndef OPERON_BACKEND_VDT_HPP
#define OPERON_BACKEND_VDT_HPP

#include "vdt/derivatives.hpp"

#endif