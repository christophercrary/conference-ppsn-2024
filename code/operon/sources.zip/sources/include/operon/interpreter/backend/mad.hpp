// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: Copyright 2019-2024 Heal Research

#ifndef OPERON_BACKEND_MAD_ARITHMETIC_FAST_HPP
#define OPERON_BACKEND_MAD_ARITHMETIC_FAST_HPP

#include "mad/derivatives.hpp"

#endif